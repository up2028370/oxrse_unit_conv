import unittest
from ..meta import classes
from ..units import km, m


class MyTestCase(unittest.TestCase):
    def test_matches(self):
        self.assertTrue(m.matches(m))

    def test_basic_conversion(self):
        self.assertEqual(km.to_si(1), 1_000)
        self.assertEqual(km.to_unit(10, km), 10)

    def test_exponented_conversion(self):
        km2 = classes.Unit(
            name='square kilometer',
            abbr='km2',
            si=classes.SIUnit('square meter', 'm', 2),
            to_si_fun=lambda x: x * 1000,
            exponent=2
        )
        self.assertEqual(km2.to_si(1), 1_000_000)
        self.assertEqual(km2.to_unit(10, km2), 10)


if __name__ == '__main__':
    unittest.main()
